package org.vitu.loader;

public interface MessageService {
    public String getMessage();
}
